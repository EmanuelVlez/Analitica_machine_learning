from distutils.command.clean import clean
import json
import os
import logging
import boto3
import time
import urllib


def lambda_handler(event, context):
    # TODO implement

    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')


    if bucket != "":
        logger.info('Corriendo \n')

        faceids=search_faces(bucket,key)

        print(faceids)

        for faceid in faceids:
            updateItemDB(faceid,'OK')

        return {
            'statusCode': 200,
            'body': json.dumps('Hello from Lambda!')
        }

    else: 

        # keys=listBucketObjects('analitica-rekognition-bucket')
        # deleteTagFromObject('analitica-rekognition-bucket',keys)
        print('Flag error')



def listBucketObjects(bucketName):

    s3 = boto3.resource('s3')

    client = boto3.client('s3')
    bucket = s3.Bucket(bucketName)
    

    keys=[] 

    try:
        
        response = client.list_objects(
            Bucket=bucketName,
            MaxKeys=123,
        )

        for key in response['Contents']:
            keys.append(key['Key'])
        
        print(keys)
        
        return keys


    except Exception as msg:
        print(f"Oops, error in list_objects: {msg}")

            

# def search_faces(keys):
def search_faces(bucket,key):

    client=boto3.client('rekognition', 'us-east-1')

    collectionId = 'collection-rekognition'
    threshold = 80
    maxFaces = 100


    print(bucket)
    print(key)
    
    response=client.search_faces_by_image(CollectionId=collectionId,
                                    Image={'S3Object':{'Bucket':bucket,'Name':key}},
                                    FaceMatchThreshold=threshold,
                                     MaxFaces=maxFaces)


    faceMatches = response['FaceMatches']
    print(faceMatches)

    listface=[]

    for match in faceMatches:
        print('FaceId:' + match['Face']['FaceId'])
        print('ImageId:' + match['Face']['ImageId'])
        print('Similarity: ' + "{:.2f}".format(match['Similarity']) + "%")
        print('Confidence: ' + str(match['Face']['Confidence']))
        # listmatches.append("{:.2f}".format(match['Similarity']) + "%")

        if match['Similarity'] > 80.0:
            listface.append( match['Face']['FaceId'])

    return listface


def deleteTagFromObject(bucketName, keys): 

    try:

        client = boto3.client('s3')
    
        for key in keys:
            response = client.delete_object_tagging(
                Bucket=bucketName,
                Key=key,
          )

    except: 
        
        print('error')
        

def updateItemDB(FaceId,status):

    print('entró a la DB \n')

    client = boto3.client('dynamodb')
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')

    try:

        response = client.update_item(
            TableName='dataset-collection-images',
            Key={
                'FaceID': {
                    'S': FaceId
                }
            },
            AttributeUpdates={
                'status': {
                    'Value': {
                        'BOOL': True
                    },
                    'Action': 'PUT'
                }
            },


        )   

        print('Actualizó DB')

    except Exception as msg:

        print(f"Oops, could not update: {msg}")

    